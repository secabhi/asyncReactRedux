import React, { Component } from 'react';

import Demo from '../containers/demo'
export default class App extends Component {
  render() {
    return (
      <div>React redux promises really
        <Demo />
      </div>
    );
  }
}